﻿namespace MindGameBackend.Models
{
    public class FileName
    {
    }
}
